import React from "react";
import { View, Text } from "react-native";

export default function NearbyScreen() {
    return (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
            <Text style={{ color: "#666" }}>附近（占位页）</Text>
        </View>
    );
}
