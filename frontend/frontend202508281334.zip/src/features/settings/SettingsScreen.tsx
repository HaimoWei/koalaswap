import React from "react";
import { View, Text } from "react-native";
export default function SettingsScreen(){ return <View style={{flex:1,alignItems:"center",justifyContent:"center"}}><Text>设置（占位/编辑资料）</Text></View>; }
