import React from "react";
import { View, Text } from "react-native";
export default function PendingReviewsScreen(){ return <View style={{flex:1,alignItems:"center",justifyContent:"center"}}><Text>待评价（占位）</Text></View>; }
