// src/services/home.ts
import { productApi } from "../lib/api";
import { unwrap } from "../lib/unwrap";
import type { ApiResponse, Page as SpringPage } from "../lib/types";

type UiPage<T> = {
    content: T[];
    page: number;
    size: number;
    totalElements: number;
    totalPages: number;
};

function toUiPage<T>(pg: SpringPage<T>): UiPage<T> {
    const page =
        (pg as any).number ??
        (pg as any).page ??
        (pg as any).pageable?.pageNumber ??
        0;
    const size =
        (pg as any).size ??
        (pg as any).pageSize ??
        (pg as any).pageable?.pageSize ??
        10;

    return {
        content: (pg as any).content ?? [],
        page,
        size,
        totalElements: (pg as any).totalElements ?? 0,
        totalPages: (pg as any).totalPages ?? 1,
    };
}

export const HomeService = {
    async list(params?: { page?: number; size?: number; sort?: string }) {
        const { page = 0, size = 10, sort = "createdAt,desc" } = params ?? {};
        // ★ 关键：解构出 AxiosResponse 的 data，再传给 unwrap
        const { data } = await productApi.get<ApiResponse<SpringPage<any>>>(
            "/api/products/home",
            { params: { page, size, sort } }
        );
        const pageObj = unwrap<SpringPage<any>>(data); // ✅ 这里不再报错
        return toUiPage<any>(pageObj);
    },
};

export default HomeService;
