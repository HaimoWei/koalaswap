package com.koalaswap.review.model;
public enum ReviewSlotStatus { PENDING, REVIEWED, EXPIRED }
