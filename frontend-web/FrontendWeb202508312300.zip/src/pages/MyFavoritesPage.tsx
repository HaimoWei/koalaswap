import { useSearchParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getFavorites, type FavoriteProductCard } from "../api/favorites";
import { removeFavorite } from "../api/products";
import type { ProductRes } from "../api/types";
import { ProductCard } from "../components/ProductCard";

function pickProduct(x: FavoriteProductCard): ProductRes {
    return (x as any).product ? (x as any).product : (x as ProductRes);
}

export function MyFavoritesPage() {
    const [sp, setSp] = useSearchParams();
    const page = parseInt(sp.get("page") || "0", 10);
    const size = parseInt(sp.get("size") || "20", 10);
    const qc = useQueryClient();

    const q = useQuery({
        queryKey: ["favorites", page, size],
        queryFn: () => getFavorites({ page, size }),
        keepPreviousData: true,
    });

    const onPage = (p: number) => {
        const next = new URLSearchParams(sp);
        next.set("page", String(p));
        setSp(next);
    };

    async function onRemove(productId: string) {
        await removeFavorite(productId);
        qc.invalidateQueries({ queryKey: ["favorites"] });
    }

    return (
        <main className="max-w-6xl mx-auto p-6 space-y-4">
            <h1 className="text-xl font-semibold">我的收藏</h1>

            {q.isLoading ? (
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {Array.from({ length: size }).map((_,i) => <div key={i} className="h-64 bg-white border rounded animate-pulse"/> )}
                </div>
            ) : q.isError ? (
                <div className="text-red-600">加载失败：{(q.error as Error).message}</div>
            ) : (q.data?.content.length ?? 0) === 0 ? (
                <div className="text-sm text-gray-600">暂无收藏</div>
            ) : (
                <>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {q.data!.content.map((item, idx) => {
                            const p = pickProduct(item);
                            return (
                                <div key={idx} className="relative">
                                    <ProductCard p={p} />
                                    <button
                                        onClick={() => onRemove(p.id)}
                                        className="absolute top-2 right-2 text-xs px-2 py-1 rounded bg-black/70 text-white"
                                    >
                                        取消收藏
                                    </button>
                                </div>
                            );
                        })}
                    </div>

                    {/* 简易分页 */}
                    {(q.data?.totalPages ?? 1) > 1 && (
                        <div className="flex items-center justify-center gap-2">
                            <button className="px-3 py-1 rounded bg-gray-100 disabled:opacity-50" disabled={page<=0} onClick={() => onPage(page-1)}>上一页</button>
                            <span className="text-sm text-gray-600">第 {page+1} / {q.data?.totalPages} 页</span>
                            <button className="px-3 py-1 rounded bg-gray-100 disabled:opacity-50" disabled={page>=(q.data!.totalPages-1)} onClick={() => onPage(page+1)}>下一页</button>
                        </div>
                    )}
                </>
            )}
        </main>
    );
}
