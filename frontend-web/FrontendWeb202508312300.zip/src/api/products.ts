import { productApi } from "./http";
import type { ApiResponse, Page } from "./types";
import type { ProductRes } from "./types";

export type SearchParams = {
    page?: number;           // 0-based
    size?: number;           // page size
    keyword?: string;
    catId?: string;
    minPrice?: number;
    maxPrice?: number;
    sort?: string;           // e.g. "createdAt,desc" / "price,asc"
};

// 首页推荐/瀑布流
export async function fetchHomeProducts(
    { page = 0, size = 20, sort = "createdAt,desc" }: { page?: number; size?: number; sort?: string }
) {
    const { data } = await productApi.get<ApiResponse<Page<ProductRes>>>(
        "/api/products/home",
        { params: { page, size, sort } }
    );
    if (!data.ok || !data.data) throw new Error(data.message || "Fetch home failed");
    return data.data;
}

// 搜索 + 筛选
export async function searchProducts(params: SearchParams) {
    const { page = 0, size = 20, keyword, catId, minPrice, maxPrice, sort = "createdAt,desc" } = params;
    const { data } = await productApi.get<ApiResponse<Page<ProductRes>>>(
        "/api/products",
        { params: { page, size, keyword, catId, minPrice, maxPrice, sort } }
    );
    if (!data.ok || !data.data) throw new Error(data.message || "Search failed");
    return data.data;
}

// 我发布的（在售/隐藏）
export async function fetchMyProducts(
    { tab = "onsale", page = 0, size = 20, sort = "updatedAt,desc" }:
        { tab?: "onsale" | "hidden"; page?: number; size?: number; sort?: string }
) {
    const { data } = await productApi.get<ApiResponse<Page<ProductRes>>>(
        "/api/products/mine",
        { params: { tab, page, size, sort } }
    );
    if (!data.ok || !data.data) throw new Error(data.message || "Fetch mine failed");
    return data.data;
}


// 详情
export async function getProduct(id: string) {
    const { data } = await productApi.get<ApiResponse<ProductRes>>(`/api/products/${id}`);
    if (!data.ok || !data.data) throw new Error(data.message || "Product not found");
    return data.data;
}

// 收藏状态查询
export async function checkFavorite(productId: string) {
    const { data } = await productApi.get<ApiResponse<{ favorited: boolean }>>(`/api/favorites/check`, {
        params: { productId },
    });
    if (!data.ok || !data.data) throw new Error(data.message || "Check favorite failed");
    return data.data.favorited;
}

// 添加收藏
export async function addFavorite(productId: string) {
    const { data } = await productApi.post<ApiResponse<boolean>>(`/api/favorites/${productId}`);
    if (!data.ok) throw new Error(data.message || "Add favorite failed");
    return true;
}

// 取消收藏
export async function removeFavorite(productId: string) {
    const { data } = await productApi.delete<ApiResponse<boolean>>(`/api/favorites/${productId}`);
    if (!data.ok) throw new Error(data.message || "Remove favorite failed");
    return true;
}