import axios from "axios";
import { useAuthStore } from "../store/auth";

// 从环境变量取各服务 Base URL
const userBase = import.meta.env.VITE_USER_API_BASE_URL;
const productBase = import.meta.env.VITE_PRODUCT_API_BASE_URL;
const orderBase = import.meta.env.VITE_ORDER_API_BASE_URL;
const reviewBase = import.meta.env.VITE_REVIEW_API_BASE_URL;
const chatBase = import.meta.env.VITE_CHAT_API_BASE_URL;

// 工具：创建实例并挂 token 拦截器
function createApi(baseURL: string) {
    const instance = axios.create({ baseURL, withCredentials: false });

    // 请求拦截：注入 Authorization 头
    instance.interceptors.request.use((config) => {
        const token = useAuthStore.getState().token;
        if (token) config.headers.Authorization = `Bearer ${token}`;
        return config;
    });

    // 响应拦截：遇到 401 清理登录态
    instance.interceptors.response.use(
        (res) => res,
        (err) => {
            if (err?.response?.status === 401) {
                useAuthStore.getState().clear();
            }
            return Promise.reject(err);
        }
    );
    return instance;
}

export const userApi = createApi(userBase);
export const productApi = createApi(productBase);
export const orderApi = createApi(orderBase);
export const reviewApi = createApi(reviewBase);
export const chatApi = createApi(chatBase);
