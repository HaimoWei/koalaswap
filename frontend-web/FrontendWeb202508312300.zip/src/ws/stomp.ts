import { Client, IMessage, StompSubscription } from "@stomp/stompjs";
import SockJS from "sockjs-client/dist/sockjs";
import { useAuthStore } from "../store/auth";

const wsBase = import.meta.env.VITE_CHAT_WS_BASE_URL; // e.g. http://localhost:12652
const WS_PATH = "/ws/chat"; // 你的 STOMP 端点

// 单例 STOMP 客户端（按需懒连接）
let client: Client | null = null;

export function getStomp(): Client {
    if (client) return client;

    client = new Client({
        // SockJS 适配器：注意这里传入的是函数
        webSocketFactory: () => new SockJS(`${wsBase}${WS_PATH}`),

        // 自动重连
        reconnectDelay: 2000,
        // 传 token：放在 STOMP CONNECT 帧头部（后端需读取）
        connectHeaders: () => {
            const token = useAuthStore.getState().token;
            return token ? { Authorization: `Bearer ${token}` } : {};
        },
        // 心跳（后端开启则配合）
        heartbeatIncoming: 10000,
        heartbeatOutgoing: 10000,

        // 可选：调试日志
        // debug: (str) => console.log("[STOMP]", str),
    });

    client.activate();
    return client;
}

// 订阅某会话的新消息
export function subscribeConversationMessages(
    conversationId: string,
    onMessage: (msg: IMessage) => void
): StompSubscription | null {
    const c = getStomp();
    if (!c.connected) {
        // 若刚激活还未连上，注册 onConnect 回调后再订阅
        const unsub = c.onConnect = () => {
            onMessage as any; // 占位
        };
    }
    return c.subscribe(`/topic/chat/conversations/${conversationId}`, onMessage);
}

// 订阅某会话的读回执
export function subscribeConversationRead(
    conversationId: string,
    onMessage: (msg: IMessage) => void
): StompSubscription | null {
    const c = getStomp();
    return c.subscribe(`/topic/chat/conversations/${conversationId}/read`, onMessage);
}
