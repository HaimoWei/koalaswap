declare module "sockjs-client/dist/sockjs" {
    import SockJS from "sockjs-client";
    export default SockJS;
}
declare module "sockjs-client/dist/sockjs.js" {
    import SockJS from "sockjs-client";
    export default SockJS;
}
