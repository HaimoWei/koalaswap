// src/main/java/com/koalaswap/chat/client/UserClient.java
package com.koalaswap.chat.client;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.koalaswap.chat.config.ExternalServicesProperties;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class UserClient {
    private final RestTemplate rt;
    private final ExternalServicesProperties props;
    private final ObjectMapper om = new ObjectMapper();

    public UserClient(RestTemplate rt, ExternalServicesProperties props) {
        this.rt = rt; this.props = props;
    }

    public static record UserBrief(UUID id, String nickname, String avatarUrl) {}

    public Map<UUID, UserBrief> batchBrief(Collection<UUID> ids) {
        if (ids == null || ids.isEmpty()) return Collections.emptyMap();
        String url = props.getUserBaseUrl() + "/api/internal/users/batch?ids=" +
                ids.stream().map(UUID::toString).collect(Collectors.joining(","));
        try {
            ResponseEntity<String> resp = rt.getForEntity(url, String.class);
            if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) return Collections.emptyMap();
            List<UserBrief> list = om.readValue(resp.getBody(), new TypeReference<List<UserBrief>>() {});
            return list.stream().collect(Collectors.toMap(UserBrief::id, u -> u, (a,b)->a, LinkedHashMap::new));
        } catch (Exception e) {
            return Collections.emptyMap(); // 出错降级为空
        }
    }
}
