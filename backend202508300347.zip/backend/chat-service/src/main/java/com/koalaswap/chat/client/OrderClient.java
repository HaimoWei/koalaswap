// src/main/java/com/koalaswap/chat/client/OrderClient.java
package com.koalaswap.chat.client;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.koalaswap.chat.config.ExternalServicesProperties;
import com.koalaswap.chat.model.OrderStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class OrderClient {
    private final RestTemplate rt;
    private final ExternalServicesProperties props;
    private final ObjectMapper om = new ObjectMapper();

    public OrderClient(RestTemplate rt, ExternalServicesProperties props) {
        this.rt = rt; this.props = props;
    }

    public static record OrderBrief(UUID id, OrderStatus status) {}

    public Map<UUID, OrderBrief> batchBrief(Collection<UUID> ids) {
        if (ids == null || ids.isEmpty()) return Collections.emptyMap();
        String url = props.getOrderBaseUrl() + "/api/internal/orders/brief/batch?ids=" +
                ids.stream().map(UUID::toString).collect(Collectors.joining(","));
        try {
            ResponseEntity<String> resp = rt.getForEntity(url, String.class);
            if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) return Collections.emptyMap();
            List<OrderBrief> list = om.readValue(resp.getBody(), new TypeReference<List<OrderBrief>>() {});
            return list.stream().collect(Collectors.toMap(OrderBrief::id, o -> o, (a,b)->a, LinkedHashMap::new));
        } catch (Exception e) { return Collections.emptyMap(); }
    }
}
