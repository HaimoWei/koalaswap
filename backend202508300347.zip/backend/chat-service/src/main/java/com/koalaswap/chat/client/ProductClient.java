// src/main/java/com/koalaswap/chat/client/ProductClient.java
package com.koalaswap.chat.client;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.koalaswap.chat.config.ExternalServicesProperties;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class ProductClient {
    private final RestTemplate rt;
    private final ExternalServicesProperties props;
    private final ObjectMapper om = new ObjectMapper();

    public ProductClient(RestTemplate rt, ExternalServicesProperties props) {
        this.rt = rt; this.props = props;
    }

    public static record ProductBrief(UUID id, UUID sellerId, String firstImageUrl, String title) {}

    public Map<UUID, ProductBrief> batchBrief(Collection<UUID> ids) {
        if (ids == null || ids.isEmpty()) return Collections.emptyMap();
        String url = props.getProductBaseUrl() + "/api/internal/products/brief/batch?ids=" +
                ids.stream().map(UUID::toString).collect(Collectors.joining(","));
        try {
            ResponseEntity<String> resp = rt.getForEntity(url, String.class);
            if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) return Collections.emptyMap();
            List<ProductBrief> list = om.readValue(resp.getBody(), new TypeReference<List<ProductBrief>>() {});
            return list.stream().collect(Collectors.toMap(ProductBrief::id, p -> p, (a,b)->a, LinkedHashMap::new));
        } catch (Exception e) { return Collections.emptyMap(); }
    }

    /** 单查用于创建会话时推导 sellerId */
    public Optional<ProductBrief> getBrief(UUID productId) {
        String url = props.getProductBaseUrl() + "/api/internal/products/brief/" + productId;
        try {
            ResponseEntity<String> resp = rt.getForEntity(url, String.class);
            if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) return Optional.empty();
            ProductBrief pb = om.readValue(resp.getBody(), ProductBrief.class);
            return Optional.ofNullable(pb);
        } catch (Exception e) { return Optional.empty(); }
    }
}
