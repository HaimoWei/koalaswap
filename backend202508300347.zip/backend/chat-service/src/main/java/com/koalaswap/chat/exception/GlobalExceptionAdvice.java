// src/main/java/com/koalaswap/chat/exception/GlobalExceptionAdvice.java
package com.koalaswap.chat.exception;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Map;

@ControllerAdvice
public class GlobalExceptionAdvice {

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<Map<String,Object>> notFound(EntityNotFoundException e) {
        return ResponseEntity.status(404).body(Map.of("code","NOT_FOUND","message",e.getMessage()));
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String,Object>> illegal(IllegalStateException e) {
        String msg = e.getMessage()==null ? "" : e.getMessage();
        if (msg.startsWith("UNAUTHORIZED")) {
            return ResponseEntity.status(401).body(Map.of("code","UNAUTHORIZED","message","login required"));
        }
        if (msg.startsWith("FORBIDDEN")) {
            return ResponseEntity.status(403).body(Map.of("code","FORBIDDEN","message","no permission"));
        }
        return ResponseEntity.badRequest().body(Map.of("code","BAD_REQUEST","message", msg));
    }

    @ExceptionHandler(org.springframework.web.server.ResponseStatusException.class)
    public ResponseEntity<Map<String,Object>> rse(org.springframework.web.server.ResponseStatusException e) {
        return ResponseEntity.status(e.getStatusCode().value())
                .body(Map.of("code", e.getStatusCode().toString(), "message", e.getReason()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String,Object>> others(Exception e) {
        // 429 由控制器直接返回；其他兜底
        return ResponseEntity.status(500).body(Map.of("code","INTERNAL_ERROR","message", e.getMessage()));
    }
}
