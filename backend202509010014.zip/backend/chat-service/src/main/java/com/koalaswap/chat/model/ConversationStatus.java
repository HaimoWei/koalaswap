// src/main/java/com/koalaswap/chat/model/ConversationStatus.java
package com.koalaswap.chat.model;
public enum ConversationStatus { OPEN, FROZEN, CLOSED }
