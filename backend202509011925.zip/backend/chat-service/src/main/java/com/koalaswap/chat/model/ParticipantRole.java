// src/main/java/com/koalaswap/chat/model/ParticipantRole.java
package com.koalaswap.chat.model;
public enum ParticipantRole { BUYER, SELLER }
