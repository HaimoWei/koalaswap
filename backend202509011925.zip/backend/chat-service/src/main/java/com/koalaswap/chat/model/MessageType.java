// src/main/java/com/koalaswap/chat/model/MessageType.java
package com.koalaswap.chat.model;
public enum MessageType { TEXT, IMAGE, SYSTEM }
