package com.koalaswap.product.repository;

import com.koalaswap.product.entity.Product;
import java.math.BigDecimal;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import com.koalaswap.product.model.ProductStatus;

public interface ProductRepository extends JpaRepository<Product, UUID> {

    /** 搜索分页（仅 active=true；关键字匹配 title/description，价格/分类可选；可排除本人） */
    @Query("""
        select p from Product p
        where p.status = :status
          and (:kwLike is null
               or lower(p.title) like :kwLike
               or lower(p.description) like :kwLike)
          and (:catId is null or p.categoryId = :catId)
          and (:minPrice is null or p.price >= :minPrice)
          and (:maxPrice is null or p.price <= :maxPrice)
          and (:excludeSellerId is null or p.sellerId <> :excludeSellerId)
        """)
    Page<Product> searchByLike(@Param("kwLike") String kwLike,
                               @Param("catId") Integer catId,
                               @Param("minPrice") BigDecimal minPrice,
                               @Param("maxPrice") BigDecimal maxPrice,
                               @Param("excludeSellerId") UUID excludeSellerId,
                               Pageable pageable);

    /** 首页专用（仅 active=true + 可选排除本人） */
    @Query("""
        select p from Product p
        where p.status = :status
          and (:excludeSellerId is null or p.sellerId <> :excludeSellerId)
        """)
    Page<Product> home(@Param("excludeSellerId") UUID excludeSellerId, Pageable pageable);

    /** 我的发布 */
    Page<Product> findBySellerId(UUID sellerId, Pageable pageable);

    // ===== 内部状态切换（给订单服务用；使用“条件更新”避免并发踩踏） =====
    @Modifying @Transactional
    @Query("update Product p set p.status = :to where p.id = :id and p.status = :from")
    int updateStatusIf(@Param("id") UUID id,
                       @Param("from") ProductStatus from,
                       @Param("to") ProductStatus to);

    @Modifying @Transactional
    @Query("update Product p set p.status = :to where p.id = :id and p.status <> :to")
    int updateStatusUnless(@Param("id") UUID id,
                           @Param("to") ProductStatus to);
}

