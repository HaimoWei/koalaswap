// backend/product-service/src/main/java/com/koalaswap/product/repository/ProductRepository.java
package com.koalaswap.product.repository;

import com.koalaswap.product.entity.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.UUID;

public interface ProductRepository extends JpaRepository<Product, UUID> {

    @Query("""
        select p from Product p
        where p.active = true
          and (:kwLike   is null or lower(p.title) like lower(:kwLike) or lower(p.description) like lower(:kwLike))
          and (:catId    is null or p.categoryId = :catId)
          and (:minPrice is null or p.price >= :minPrice)
          and (:maxPrice is null or p.price <= :maxPrice)
          and (:excludeSellerId is null or p.sellerId <> :excludeSellerId)
    """)
    Page<Product> searchByLike(
            @Param("kwLike") String kwLike,
            @Param("catId") Integer catId,
            @Param("minPrice") BigDecimal minPrice,
            @Param("maxPrice") BigDecimal maxPrice,
            @Param("excludeSellerId") UUID excludeSellerId,
            Pageable pageable
    );

    Page<Product> findBySellerId(UUID sellerId, Pageable pageable);
}
