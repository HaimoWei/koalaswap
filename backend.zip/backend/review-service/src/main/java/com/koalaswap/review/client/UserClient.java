package com.koalaswap.review.client;

import com.koalaswap.common.dto.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;


import java.util.*;

@Component @RequiredArgsConstructor
public class UserClient {
    @Value("${app.services.user.base-url:http://localhost:8081}")
    private String baseUrl;

    private RestClient client(){ return RestClient.builder().baseUrl(baseUrl).build(); }

    public List<UserBrief> briefBatch(List<UUID> ids) {
        var type = new ParameterizedTypeReference<ApiResponse<List<UserBrief>>>(){};
        var req = Map.of("ids", ids);
        var resp = client().post().uri("/api/users/brief")
                .header(HttpHeaders.ACCEPT, "application/json")
                .body(req).retrieve().body(type);
        return resp != null && resp.ok() && resp.data() != null ? resp.data() : List.of();
    }

    public UserBrief briefOne(UUID id) {
        var type = new ParameterizedTypeReference<ApiResponse<UserBrief>>(){};
        var resp = client().get().uri("/api/users/{id}/brief", id)
                .header(HttpHeaders.ACCEPT, "application/json")
                .retrieve().body(type);
        return resp != null ? resp.data() : null;
    }

    public record UserBrief(UUID id, String displayName, String avatarUrl) {}
}
