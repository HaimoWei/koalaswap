package com.koalaswap.order.dto;

/** 模拟支付请求（预留真实支付方式） */
public record PayReq(String method) {}
