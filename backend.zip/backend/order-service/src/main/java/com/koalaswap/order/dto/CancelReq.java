package com.koalaswap.order.dto;

/** 取消原因（可选） */
public record CancelReq(String reason) {}
