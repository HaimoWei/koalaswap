// src/main/java/com/koalaswap/chat/model/SystemEvent.java
package com.koalaswap.chat.model;
public enum SystemEvent { ORDER_PLACED, PAID, SHIPPED, COMPLETED, CANCELLED }
